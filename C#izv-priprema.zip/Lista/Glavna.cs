﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista
{
    public partial class Glavna : Form
    {
        
        public Glavna()
        {
            InitializeComponent();
        }

        private void btnDodajRijec_Click(object sender, EventArgs e)
        {
            
        }

        void AzurirajListBox()
        {
            
        }

        private void btnDodajPozicija_Click(object sender, EventArgs e)
        {
            
        }

        private void btnDodajVise_Click(object sender, EventArgs e)
        {
            
        }

        private void btnUkloni_Click(object sender, EventArgs e)
        {
            
        }

        private void btnIsprazni_Click(object sender, EventArgs e)
        {
            
        }
    }
}
